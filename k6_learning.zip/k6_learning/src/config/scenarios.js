export const scenarios = {
    smoke: {
        executor: 'shared-iterations',
        vus: 1,
        iterations: 1,
        maxDuration: '10s',
    },
    load: {
        executor: 'ramping-vus',
        startVUs: 0,
        stages: [
            { duration: '1m', target: 20 }, // Ramp-up to 20 VUs
            { duration: '3m', target: 20 }, // Maintain 20 VUs
            { duration: '1m', target: 0 },  // Ramp-down to 0 VUs
        ],
    },
    stress: {
        executor: 'ramping-vus',
        startVUs: 0,
        stages: [
            { duration: '1m', target: 50 },  // Ramp-up to 50 VUs
            { duration: '2m', target: 50 },  // Maintain 50 VUs
            { duration: '1m', target: 100 }, // Spike to 100 VUs
            { duration: '2m', target: 100 }, // Maintain 100 VUs
            { duration: '1m', target: 0 },   // Cool down to 0 VUs
        ],
    },
    soak: {
        executor: 'ramping-vus',
        startVUs: 0,
        stages: [
            { duration: '2m', target: 30 }, // Ramp-up
            { duration: '4h', target: 30 }, // Run for hours
            { duration: '2m', target: 0 },  // Ramp-down
        ],
    }
};
