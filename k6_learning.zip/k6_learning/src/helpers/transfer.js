import http from 'k6/http';
import { check } from 'k6';
import { uuidv4 } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

export function transfer(baseUrl, token, apiKey, sourceAccountId, destAccountNumber, destBankCode, amount, currency, remark) {
    const url = `${baseUrl}/v1/transfers`;
    const payload = JSON.stringify({
        sourceAccountId: sourceAccountId,
        destinationAccountNumber: destAccountNumber,
        destinationBankCode: destBankCode,
        amount: amount,
        currency: currency,
        remark: remark
    });

    const params = {
        headers: {
            'Authorization': `Bearer ${token}`,
            'X-API-Key': apiKey,
            'Idempotency-Key': uuidv4(),
            'Content-Type': 'application/json',
        },
    };

    const res = http.post(url, payload, params);

    check(res, {
        'transfer status is 200': (r) => r.status === 200,
        'transfer success is true': (r) => {
            try {
                return r.json('success') === true;
            } catch (e) {
                return false;
            }
        },
    });

    return res;
}
