import http from 'k6/http';
import { check } from 'k6';

export function login(baseUrl, email, password) {
    const url = `${baseUrl}/api/v1/login`;
    const payload = JSON.stringify({
        email: email,
        password: password,
    });

    const params = {
        headers: {
            'Content-Type': 'application/json',
        },
    };

    const res = http.post(url, payload, params);

    

    check(res, {
        'login status is 200': (r) => r.status === 200,
        'login success is true': (r) => {
            try {
                return r.json('success') === true;
            } catch (e) {
                return false;
            }
        },
        'has token': (r) => {
            try {
                return r.json('data.token') !== undefined;
            } catch (e) {
                return false;
            }
        },
    });

    try {
        return res.json('data.token');
    } catch (e) {
        return null;
    }
}
