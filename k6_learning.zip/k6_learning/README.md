# k6 Performance Test Project

Project performance test ini digunakan untuk melakukan simulasi transaksi pada endpoint `/v1/transfers` dengan melakukan authentication awal ke `/api/v1/login`.

## Setup
Pastikan Anda sudah menginstal **[k6](https://k6.io/docs/get-started/installation/)** di mesin Anda.

## Struktur Folder:
- `main.js`: Main entry point untuk menjalankan k6 runner. File ini mendefinisikan setup code (login) dan action utama k6 (transfer).
- `src/helpers/auth.js`: Helper file berisi function untuk proses Login & verifikasi.
- `src/helpers/transfer.js`: Helper file berisi function untuk proses HTTP transfer dana.
- `src/config/scenarios.js`: File mengatur skenario pengujian: Smoke, Load, Stress, dan Soak test.

## Environment Variables
Anda dapat memodifikasi environment berikut saat run k6 (di bawah merupakan value defaultnya):
- `BASE_URL="http://localhost:8080"`
- `EMAIL="test@example.com"`
- `PASSWORD="password123"`
- `API_KEY="dev-api-key"`
- `SOURCE_ACCOUNT_ID="12345"`
- `DEST_ACCOUNT_NUMBER="903694413293"`
- `DEST_BANK_CODE="BCA"`
- `AMOUNT=20000`
- `CURRENCY="IDR"`
- `REMARK="Invoice Payment"`

Serta `TEST_TYPE` yang bisa berupa `smoke`, `load`, `stress`, atau `soak`.

## Cara Menjalankan

Buka Terminal / Command Prompt pada direktori `c:\code\k6\k6_learning` lalu jalankan perintah berikut:

### 1. Smoke Test (Validasi fungsi)
```powershell
k6 run -e TEST_TYPE=smoke -e BASE_URL=http://localhost:8080 -e EMAIL=admin@example.com -e PASSWORD=rahasia main.js
```

### 2. Load Test (Mengetes sistem pada traffic normal)
```powershell
k6 run -e TEST_TYPE=load -e BASE_URL=http://localhost:8080 -e EMAIL=admin@example.com -e PASSWORD=rahasia main.js
```

### 3. Stress Test (Mencari limitasi sistem dengan load tinggi)
```powershell
k6 run -e TEST_TYPE=stress -e BASE_URL=http://localhost:8080 -e EMAIL=admin@example.com -e PASSWORD=rahasia main.js
```

### 4. Soak Test (Menguji pada waktu panjang untuk melihat memory leak/kebocoran resource)
```powershell
k6 run -e TEST_TYPE=soak -e BASE_URL=http://localhost:8080 -e EMAIL=admin@example.com -e PASSWORD=rahasia main.js
```
