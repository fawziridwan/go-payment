saya berencana melakukan pengujian aplikasi pada endpoint /transfer
dimana endpoint tersebut pertama membutuhkan endpoint /login

curl /login
curl --location 'https://backend-course-gamma.vercel.app/api/v1/login' \
--header 'Content-Type: application/json' \
--data-raw '{
  "email": "Imani.Littel@gmail.com",
  "password": "P@ssw0rd"
}'
contoh response

{
    "success": true,
    "statusCode": 200,
    "message": "Login successfully",
    "data": {
        "user": {
            "id": 72,
            "name": "Ms. Cameron Robel",
            "email": "Imani.Littel@gmail.com"
        },
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NzIsImlhdCI6MTc4MTcxMzQxMiwiZXhwIjoxNzgxNzE3MDEyfQ.oEs1D3IYa9q-4mpyFc02MmeHpWoFFosrreo-r9Br8k4"
    }
}

output yg diambil adalah token yg akan dipakai di endpoint /transfer
curl /transfer
curl --location 'https://payment-inky-one.vercel.app/v1/transfers' \
--header 'Content-Type: application/json' \
--header 'X-API-Key: dev-api-key' \
--header 'Idempotency-Key: {{idempotency_key}}' \
--data '{
    "sourceAccountId": "",
    "destinationAccountNumber": "903694413293",
    "destinationBankCode": "BCA",
    "amount": 20000,
    "currency": "IDR",
    "remark": "Invoice Payment"
}'

pre request script
// Generate a unique Idempotency-Key for each request
pm.variables.set('idempotency_key', pm.variables.replaceIn('{{$guid}}'));


response
{
    "success": true,
    "data": {
        "transactionId": "31b0aacc-9eca-4c4a-bed3-a847079b510d",
        "referenceNumber": "REF-eabd02c3",
        "status": "SUCCESS",
        "amount": "20000",
        "fee": "2500",
        "timestamp": "2026-06-17T16:24:30.508263Z"
    }
}

dari 2 endpoint diatas, saya ingin membuat skrip simple performance test menggunakan k6, 
bagaimana kan implementasinya untuk menjalankan load test & struktur folder nya seperti apa 