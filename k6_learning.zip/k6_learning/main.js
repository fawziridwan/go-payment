import { login } from './src/helpers/auth.js';
import { transfer } from './src/helpers/transfer.js';
import { scenarios } from './src/config/scenarios.js';

// Base URLs
const LOGIN_BASE_URL =
    __ENV.LOGIN_BASE_URL || 'https://backend-course-gamma.vercel.app';

const TRANSFER_BASE_URL =
    __ENV.TRANSFER_BASE_URL || 'https://payment-inky-one.vercel.app';

// Credentials
const EMAIL = __ENV.EMAIL || 'Imani.Littel@gmail.com';
const PASSWORD = __ENV.PASSWORD || 'P@ssw0rd';

// Transfer Data
const API_KEY = __ENV.API_KEY || 'dev-api-key';
const SOURCE_ACCOUNT_ID = __ENV.SOURCE_ACCOUNT_ID || '12345';
const DEST_ACCOUNT_NUMBER = __ENV.DEST_ACCOUNT_NUMBER || '903694413293';
const DEST_BANK_CODE = __ENV.DEST_BANK_CODE || 'BCA';
const AMOUNT =
    typeof __ENV.AMOUNT !== 'undefined'
        ? parseInt(__ENV.AMOUNT)
        : 20000;
const CURRENCY = __ENV.CURRENCY || 'IDR';
const REMARK = __ENV.REMARK || 'Invoice Payment';

const TEST_TYPE = __ENV.TEST_TYPE || 'smoke';

const scenarioConfig = scenarios[TEST_TYPE];

if (!scenarioConfig) {
    throw new Error(
        `Unknown TEST_TYPE: ${TEST_TYPE}. Available types are: smoke, load, stress, soak.`
    );
}

export const options = {
    thresholds: {
        http_req_failed: ['rate<0.01'],
        http_req_duration: ['p(95)<2000'],
    },
    scenarios: {
        current_test: scenarioConfig,
    },
};

export function setup() {
    const token = login(
        LOGIN_BASE_URL,
        EMAIL,
        PASSWORD
    );

    if (!token) {
        throw new Error(
            'Authentication failed or token is missing in setup phase.'
        );
    }

    return { token };
}

export default function (data) {
    transfer(
        TRANSFER_BASE_URL,
        data.token,
        API_KEY,
        SOURCE_ACCOUNT_ID,
        DEST_ACCOUNT_NUMBER,
        DEST_BANK_CODE,
        AMOUNT,
        CURRENCY,
        REMARK
    );
}