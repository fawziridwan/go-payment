Buatkan project k6 performance testing untuk flow berikut:

1. Login ke endpoint:
   POST /api/v1/login

Request:
{
"email": "<EMAIL>",
"password": "<PASSWORD>"
}

Ambil token dari response JSON pada field:
data.token

2. Gunakan token tersebut untuk melakukan request:

POST /v1/transfers

Header:

* Authorization: Bearer <token>
* X-API-Key: dev-api-key
* Idempotency-Key: UUID per request

Body:
{
"sourceAccountId": "",
"destinationAccountNumber": "903694413293",
"destinationBankCode": "BCA",
"amount": 20000,
"currency": "IDR",
"remark": "Invoice Payment"
}

Requirements:

* Gunakan k6 terbaru.
* Login dilakukan pada setup() agar tidak login setiap iterasi.
* Buat helper terpisah untuk auth dan transfer.
* Tambahkan check() untuk status 200 dan success=true.
* Tambahkan threshold:

  * error rate < 1%
  * p95 < 2 detik
* Sediakan skenario:

  * smoke
  * load
  * stress
  * soak
* Gunakan environment variable untuk seluruh konfigurasi.
* Generate struktur folder dan seluruh source code yang siap dijalankan.
* Sertakan command menjalankan test.
