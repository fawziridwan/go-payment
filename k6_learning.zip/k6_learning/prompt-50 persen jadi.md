# Objective

Buatkan project Performance Testing menggunakan k6 untuk menguji endpoint Transfer API yang membutuhkan autentikasi Login API terlebih dahulu.

# Requirements

## Login API

Endpoint:

POST https://backend-course-gamma.vercel.app/api/v1/login

Request:

```json
{
  "email": "Imani.Littel@gmail.com",
  "password": "P@ssw0rd"
}
```

Contoh Response:

```json
{
  "success": true,
  "statusCode": 200,
  "message": "Login successfully",
  "data": {
    "user": {
      "id": 72,
      "name": "Ms. Cameron Robel",
      "email": "Imani.Littel@gmail.com"
    },
    "token": "JWT_TOKEN"
  }
}
```

Token berada pada:

```text
data.token
```

Token tersebut harus digunakan sebagai Bearer Token untuk endpoint transfer.

---

## Transfer API

Endpoint:

POST https://payment-inky-one.vercel.app/v1/transfers

Headers:

```http
Content-Type: application/json
Authorization: Bearer <token>
X-API-Key: dev-api-key
Idempotency-Key: <uuid>
```

Request:

```json
{
  "sourceAccountId": "",
  "destinationAccountNumber": "903694413293",
  "destinationBankCode": "BCA",
  "amount": 20000,
  "currency": "IDR",
  "remark": "Invoice Payment"
}
```

Contoh Response:

```json
{
  "success": true,
  "data": {
    "transactionId": "31b0aacc-9eca-4c4a-bed3-a847079b510d",
    "referenceNumber": "REF-eabd02c3",
    "status": "SUCCESS",
    "amount": "20000",
    "fee": "2500",
    "timestamp": "2026-06-17T16:24:30.508263Z"
  }
}
```

---

# Expected Project Structure

```text
k6-performance-test/
│
├── config/
│   └── env.js
│
├── helpers/
│   ├── auth.js
│   ├── transfer.js
│   └── headers.js
│
├── scenarios/
│   ├── smoke-transfer.js
│   ├── load-transfer.js
│   ├── stress-transfer.js
│   └── soak-transfer.js
│
├── reports/
│
├── package.json
├── README.md
└── .gitignore
```

# Technical Requirements

1. Gunakan k6 versi terbaru.
2. Implementasikan reusable helper untuk login.
3. Implementasikan reusable helper untuk transfer.
4. Generate Idempotency-Key menggunakan UUID setiap request transfer.
5. Gunakan setup() untuk login sekali dan share token ke seluruh Virtual Users.
6. Implementasikan check() untuk validasi:

   * HTTP Status = 200
   * success = true
   * transactionId tidak null
7. Tambahkan threshold:

```javascript
thresholds: {
  http_req_failed: ['rate<0.01'],
  http_req_duration: ['p(95)<2000']
}
```

8. Tambahkan custom metrics:

   * Transfer Success Rate
   * Transfer Failure Rate
   * Transfer TPS

9. Tambahkan environment variable:

   * LOGIN_URL
   * TRANSFER_URL
   * API_KEY
   * EMAIL
   * PASSWORD

10. Jangan hardcode value selain default sample.

# Scenarios

## Smoke Test

* 1 VU
* 30 detik

## Load Test

* 20 VU
* 5 menit

## Stress Test

* Ramp:

  * 10 VU
  * 50 VU
  * 100 VU

## Soak Test

* 20 VU
* 1 jam

# Deliverables

Generate seluruh source code project.

Pastikan seluruh file lengkap dan siap dijalankan menggunakan:

```bash
npm install
k6 run scenarios/load-transfer.js
```

Buatkan juga README.md yang berisi:

* Installation
* Configuration
* Run Smoke Test
* Run Load Test
* Run Stress Test
* Run Soak Test
* Sample Output Result
* Troubleshooting

```
```
